﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DistantPoint_App.Models
{
    public class JsonFile
    {
        public IFormFile MyJson { set; get; }
    }
}
