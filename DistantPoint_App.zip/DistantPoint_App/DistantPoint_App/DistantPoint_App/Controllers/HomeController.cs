﻿using DistantPoint_App.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DistantPoint_App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index( string errorMessage = "" )
        {
            ViewBag.ErrorMsg = errorMessage;
            return View();
        }

        [HttpPost]
        public IActionResult Upload(JsonFile jsonfile)
        {
            var json = jsonfile.MyJson;
            dynamic jsonResult = new JObject();
            HashSet<Dictionary<string, string>> claimsResult = new HashSet<Dictionary<string, string>>();

            var contentType = jsonfile.MyJson.ContentType;
            if (contentType == "application/json" || contentType == "text/plain")
            {

                string jsonContent = "";
                using (var reader = new StreamReader(jsonfile.MyJson.OpenReadStream()))
                {
                    jsonContent = reader.ReadToEnd();
                }

                dynamic jsonObject = JsonConvert.DeserializeObject(jsonContent);
                if (jsonObject == null)
                {
                    return RedirectToAction("Index", "Home", new { errorMessage = "Uploaded file content contains invalid Json!!!" });
                }


                foreach (var jsonElement in jsonObject)
                {
                    if (jsonElement["Claims"] != null)
                    {
                        foreach (var jsonClaim in jsonElement["Claims"])
                        {
                            Dictionary<string, string> claimElement = new Dictionary<string, string> {
                            { "ClaimType", (string)jsonClaim["ClaimType"] },
                            { "Value", (string)jsonClaim["Value"] }
                        };

                            if (!claimsResult.Contains(claimElement))
                            {
                                claimsResult.Add(claimElement);
                            }
                        }
                    }
                }
            
            } else {
                return RedirectToAction("Index", "Home", new { errorMessage = "Please upload a Json or Text file!!!" });
            }

            if (claimsResult.Count > 0)
            {
                return File(System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(claimsResult)), "application/json", "NewClaims.json");
            } else
            {
                return RedirectToAction("Index", "Home", new { errorMessage = "No Claims elements are found in the uploaded Json file!!!" });
            }
        }
        
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
